# Instructions

1. Password for level0: CTFL{level0!}
2. There are 21 levels in total.
3. Each level is password protected using a tool called "mcrypt". Install it on our machine.
4. Flag you get in this level is password to unlock the next level.
5. Password format:
	* Every password is of the form ```CTFL{some-string-here}```.
	* If a flag you get is not of the above form, then convert it to that form.
		* If you get "hacker1234" as the flag, then you will have to submit "CTFL{hacker1234}".
